## Example Introduction to Time Series 2.2

class(AirPassengers)

start(AirPassengers)

end(AirPassengers)

frequency(AirPassengers)

deltat(AirPassengers)

plot(AirPassengers, main = "Passengers", ylab = "Number (in 1000s)")
grid()
