## Example Introduction to Time Series 2.1

class(iris)

names(iris)

nrow(iris)
