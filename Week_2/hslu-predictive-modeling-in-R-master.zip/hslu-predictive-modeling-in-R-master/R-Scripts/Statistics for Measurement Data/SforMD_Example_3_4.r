## Example 3.4 p-value

# One sided p value:
1-pt(3.1246, df=12)
# Two sided p value:
2*(1-pt(3.1246, df=12))


