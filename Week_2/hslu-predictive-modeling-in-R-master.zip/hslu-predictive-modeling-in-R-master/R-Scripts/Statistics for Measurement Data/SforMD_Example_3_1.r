## Exampole 3.1 z test Fusion heat

qnorm(0.025)

qnorm(0.025,80.0,0.01/sqrt(13))

qnorm(0.975,80.0,0.01/sqrt(13))